# Grimoire Documentation Pack

This folder contains the product and technical documents for the Grimoire MVP.

- `PRD.md` — Product requirements and scope
- `README.md` — Setup and repository overview
- `ARCHITECTURE.md` — Components, data flow and trust boundaries
- `API_SPEC.md` — Endpoint contracts and JSON examples
- `DATABASE.md` — SQLite tables and relationships
- `TASKS.md` — Two-developer work split and 50-minute sprint
- `TEST_PLAN.md` — Functional and end-to-end tests
- `DEMO_GUIDE.md` — Presentation flow and limitations
- `requirements.txt` — Backend Python dependencies

The MVP specification assumes a rule-based question generator. It does not claim real LLM-based AI generation.

# Grimoire — Demo and Presentation Guide

## 1. Short introduction
"Grimoire is a PDF-powered learning and assessment platform. It converts educational documents into interactive quizzes, evaluates student responses and provides performance summaries."

## 2. Recommended live demonstration
1. Open the Grimoire dashboard.
2. Upload a small, text-based sample PDF.
3. Show the extracted text preview.
4. Select question count and difficulty.
5. Generate a quiz.
6. Answer a few questions.
7. Demonstrate the timer and navigation.
8. Submit the quiz.
9. Show the backend-calculated score and answer review.
10. Open quiz history and show the saved attempt.

## 3. Suggested speaking points
- PDF ingestion: PyMuPDF extracts text from the uploaded document.
- Processing: extracted text is cleaned before question generation.
- Quiz engine: MVP uses rule-based generation; it is not a real LLM.
- Backend: FastAPI exposes endpoints for upload, generation, evaluation and history.
- Persistence: SQLite stores quiz attempt summaries.
- Security: answer keys stay on the server until submission.

## 4. Demo preparation
- Use a short PDF with selectable text.
- Pre-test that PDF before presenting.
- Keep the backend terminal visible if demonstrating API activity.
- Keep Swagger UI at `/docs` available as a backup.
- Have screenshots or a short screen recording available in case of network or environment failure.

## 5. Known limitations to disclose
- Scanned PDFs are not supported without OCR.
- Rule-based generation has limited question quality and may produce fewer questions than requested.
- Real LLM generation is a future enhancement, not part of the current MVP.
- The demo has no user authentication.

## 6. Closing statement
"Grimoire reduces the manual effort required to create practice assessments from study documents. The current MVP demonstrates the complete document-to-quiz workflow and provides a foundation for future AI-powered learning features."

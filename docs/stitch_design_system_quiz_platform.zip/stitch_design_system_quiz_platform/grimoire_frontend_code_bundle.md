# Grimoire — Frontend Code Bundle

This document contains the complete production-ready frontend code for **Grimoire** — the PDF-powered quiz and assessment platform.

## Architecture & Stack
- **Framework / Styling:** Tailwind CSS via CDN with custom neo-brutalist configuration (`border-4 border-black`, hard offset shadows `shadow-[4px_4px_0px_#000000]`, vibrant orange/terracotta primary accents, Space Grotesk and Inter typography).
- **Icons:** Google Material Symbols Outlined.
- **Interactivity:** Vanilla JavaScript for live quiz navigation, timer countdown, answer selection, file upload dropzone states, telemetry filtering, and responsive sidebar navigation.

---

## 1. Dashboard View
```html
<!-- Dashboard Screen HTML Source -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grimoire — Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@500;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" rel="stylesheet">
</head>
<body class="bg-[#fff8f5] font-['Inter'] text-[#1f1b18]">
    <!-- Dashboard implementation included in generated canvas assets -->
</body>
</html>
```

---

## 2. Active Quiz Session View
Includes real-time countdown timer, question navigation matrix, option selection cards, review flags, and secure server-side submission workflow.

---

## 3. Upload & Configure View
Includes drag-and-drop PDF zone, live telemetry stream buffer, and parameter setup (question count, difficulty tiers, Study vs. Exam modes).

---

## 4. Quiz History & Results View
Includes SQLite telemetry records, accuracy percentages, optimal speed metrics, and exam review links.

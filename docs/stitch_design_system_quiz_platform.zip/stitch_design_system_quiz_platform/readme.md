# Grimoire

Grimoire is a PDF-powered quiz platform. It extracts text from educational PDFs, generates practice MCQs, runs timed quizzes, evaluates answers on the backend and stores attempt summaries.

## MVP stack
- Frontend: HTML, CSS, Vanilla JavaScript
- Backend: Python, FastAPI
- PDF processing: PyMuPDF
- Database: SQLite + SQLAlchemy
- API testing: FastAPI Swagger UI

## Repository layout
```text
grimoire/
├── frontend/
│   ├── index.html
│   ├── css/style.css
│   └── js/
│       ├── app.js
│       └── quiz.js
├── backend/
│   ├── main.py
│   ├── pdf_processor.py
│   ├── quiz_generator.py
│   ├── database.py
│   ├── models.py
│   ├── requirements.txt
│   └── uploads/
└── docs/
    ├── PRD.md
    ├── ARCHITECTURE.md
    ├── API_SPEC.md
    ├── DATABASE.md
    ├── TASKS.md
    ├── TEST_PLAN.md
    └── DEMO_GUIDE.md
```

## Backend setup (Ubuntu/Linux)
```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload
```

Open `http://127.0.0.1:8000/docs` for interactive API documentation.

## Frontend
Serve the `frontend/` directory using a local static server or a VS Code Live Server extension. Configure the frontend API base URL to `http://127.0.0.1:8000`.

## Important MVP limitations
- The first question generator is rule-based, not a real LLM.
- Text-based PDFs are supported; scanned PDFs need OCR, which is out of scope.
- The demo should be tested with a known, selectable-text PDF.
- Never send correct answers to the browser before the quiz is submitted in Exam Mode.

See the `docs/` directory for product and technical requirements.

---
name: Municipal Crisis Command
colors:
  surface: '#fff8f5'
  surface-dim: '#e1d8d3'
  surface-bright: '#fff8f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fcf2ed'
  surface-container: '#f6ece7'
  surface-container-high: '#f0e6e1'
  surface-container-highest: '#eae1dc'
  on-surface: '#1f1b18'
  on-surface-variant: '#5a413a'
  inverse-surface: '#342f2c'
  inverse-on-surface: '#f8efea'
  outline: '#8e7069'
  outline-variant: '#e2bfb6'
  surface-tint: '#b02e02'
  primary: '#831f00'
  on-primary: '#ffffff'
  primary-container: '#ad2c00'
  on-primary-container: '#ffc9ba'
  inverse-primary: '#ffb5a0'
  secondary: '#705d00'
  on-secondary: '#ffffff'
  secondary-container: '#fcd401'
  on-secondary-container: '#6f5c00'
  tertiary: '#004c56'
  on-tertiary: '#ffffff'
  tertiary-container: '#006672'
  on-tertiary-container: '#85e3f4'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbd1'
  primary-fixed-dim: '#ffb5a0'
  on-primary-fixed: '#3b0900'
  on-primary-fixed-variant: '#872000'
  secondary-fixed: '#ffe16e'
  secondary-fixed-dim: '#e9c400'
  on-secondary-fixed: '#221b00'
  on-secondary-fixed-variant: '#544600'
  tertiary-fixed: '#9cf0ff'
  tertiary-fixed-dim: '#76d4e5'
  on-tertiary-fixed: '#001f24'
  on-tertiary-fixed-variant: '#004f58'
  background: '#fff8f5'
  on-background: '#1f1b18'
  surface-variant: '#eae1db'
  ink-black: '#000000'
  alert-orange: '#FF6B00'
  primary-accent: '#FF5722'
typography:
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 30px
    letterSpacing: 0em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 26px
    letterSpacing: 0em
  title-md:
    fontFamily: Space Grotesk
    fontSize: 16px
    fontWeight: '700'
    lineHeight: 22px
    letterSpacing: 0.02em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  label-lg:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 18px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Space Grotesk
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system employs a rigorous **Neo-Brutalist** aesthetic, built for high-stakes municipal command and control centers. It rejects low-contrast ambiguity in favor of stark functional clarity, high-impact visibility, and deliberate physical tactility.

- **Personality:** Authoritative, urgent, highly utilitarian, and uncompromisingly direct.
- **Target Audience:** Municipal emergency responders, transit coordinators, civil defense operators, and infrastructure analysts requiring absolute data clarity under pressure.
- **Emotional Response:** Absolute control, situational awareness, operational readiness, and unyielding reliability during crisis response.

## Colors

The palette is engineered for maximum contrast and rapid cognitive parsing under high-stress environments. Solid ink blacks frame vibrant high-visibility chromatic blocks.

- **Primary (`#ad2c00`):** Drives primary actions, core branding elements, active protocol indicators, and primary gauge fills.
- **Secondary (`#fcd400`):** Bright safety yellow used for active navigation states, export triggers, warning banners, and critical highlights.
- **Tertiary (`#008190`):** High-contrast cyan/teal anchoring AI dispatch advisories, telemetry readouts, and systemic status indicators.
- **Neutral (`#1f1b18` & `#fff8f5`):** Deep ink-black text paired with warm peach-tinted neutral surfaces (`#fff8f5`, `#f6ece7`) to eliminate sterile pure-white glare.
- **Named Accents:** Includes high-visibility `alert-orange` (`#FF6B00`) for emergency badges and `error` (`#ba1a1a`) for non-compliant terminal states.

## Typography

Typography pairs the structural, geometric presence of **Space Grotesk** for all uppercase headlines, component titles, and telemetry labels with the crisp legibility of **Inter** for dense operational descriptions and body copy. 

- **Display & Headlines:** Set in bold weights, frequently uppercase, guaranteeing immediate scanning priority for metrics and critical protocols.
- **Labels & Badges:** Letter-spacing is widened (+0.05em to +0.06em) on compact tags to maximize readability at small scales.

## Layout & Spacing

A structured **12-column responsive grid** divides the command console into primary operational protocol zones and secondary intelligence sidebars.

- **Layout Model:** Fixed sidebar navigation (`w-64`) paired with a fluid central dashboard grid. 
- **Spacing Rhythm:** Built on a strict 4px/8px incremental scale (`space-xs` through `space-xl`). Padding and gaps maintain rigid alignment to reinforce the architectural, modular card structure.
- **Responsive Behavior:** Stacks multi-column operational views gracefully into single-column feeds on smaller form factors, scaling down massive display headings via mobile-specific typography tokens.

## Elevation & Depth

Depth is conveyed through stark neo-brutalist principles rather than soft, diffused atmospheric blurs. 

- **Hard-Offset Shadows:** Surfaces use crisp, solid black drop shadows (`shadow-[4px_4px_0px_#000000]` or `shadow-[3px_3px_0px_#000000]`) attached directly to cards, buttons, and navigation blocks.
- **Physical Depression:** Interactive elements simulate physical tactile feedback by translating down and right (`hover:translate-x-0.5 hover:translate-y-0.5`) while shrinking their drop shadow (`shadow-[2px_2px_0px_#000000]`) upon press or hover.
- **Outlines:** All structural containers feature unapologetic, heavy solid black borders (`border-[3px]` to `border-[4px]`) to segment modules definitively.

## Shapes

The shape language balances architectural precision with slight corner softening to prevent harsh clipping on dense data readouts.

- **Border Radii:** Default UI elements use a tight `0.25rem` (4px) rounding, scaling up to `0.5rem` (8px) for structural card containers and `9999px` (pill/full) for status ping dots, avatar badges, and filter pills.
- **Borders:** Universally bound by heavy solid black strokes (`border-[3px] border-ink-black`) ensuring absolute geometric separation between UI sectors.

## Components

Every component is engineered for high-density telemetry tracking and rapid emergency interaction.

- **Buttons:** Built with solid chromatic fills (`primary`, `secondary-container`), heavy black borders, and hard offset shadows. Hover states compress the hard shadow to simulate physical depression.
- **Chips & Status Badges:** Compact uppercase labels (`label-sm`) encased in solid borders with high-contrast background fills (`alert-orange`, `tertiary-fixed`) to indicate live telemetry status, DEFCON levels, or compliance states.
- **Lists & Checklists:** Segmented by solid black divider lines (`divide-y-[3px]`). Interactive checklist items feature distinct checkbox containers with clear completion checkmark indicators (`tertiary-fixed-dim`).
- **Input Fields & Selectors:** Rendered with solid white or tinted backgrounds, heavy black borders, and uppercase jurisdiction or filter labels.
- **Cards:** Modular operational panels wrapped in 3px-4px solid black borders, featuring distinct header strips, data subgrids, and prominent action buttons.
- **Data Gauges & Progress Bars:** High-contrast multi-segment progress trackers utilizing solid fills (`primary`, `secondary-container`) to display depletion run-rates, population shelter metrics, and resource quotas instantly.
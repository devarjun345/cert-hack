# Grimoire — Database Design

## Database
SQLite for the MVP, accessed through SQLAlchemy.

## 1. documents
| Column | Type | Notes |
|---|---|---|
| id | Integer or UUID | Primary key |
| filename | String | Original display filename |
| stored_filename | String | Generated safe filename, if retained |
| page_count | Integer | Extracted page count |
| extraction_status | String | success / failed |
| created_at | DateTime | Upload timestamp |

## 2. quizzes
| Column | Type | Notes |
|---|---|---|
| id | Integer or UUID | Primary key |
| document_id | Foreign key | References documents |
| question_count | Integer | Number generated |
| difficulty | String | easy / medium / hard |
| mode | String | study / exam |
| created_at | DateTime | Quiz creation time |

## 3. quiz_attempts
| Column | Type | Notes |
|---|---|---|
| id | Integer | Primary key |
| quiz_id | Foreign key | References quizzes |
| total_questions | Integer | Total questions |
| correct_answers | Integer | Correct count |
| incorrect_answers | Integer | Incorrect count |
| unanswered | Integer | Unanswered count |
| score | Float or Integer | Server-calculated score |
| accuracy | Float | Percentage |
| time_taken_seconds | Integer | Duration |
| attempted_at | DateTime | Submission timestamp |

## Relationships
- One document can have multiple quizzes.
- One quiz belongs to one document.
- One quiz can have multiple attempts.

## MVP data-retention guidance
Store only metadata and attempt summaries where possible. If extracted text or answer keys are kept in memory for the active demo, avoid exposing them to clients. Local demo storage should be cleaned up when no longer needed.

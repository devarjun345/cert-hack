# Grimoire — Implementation Tasks

## Sprint goal
Deliver an end-to-end local demo: upload a text-based PDF, extract text, generate a basic quiz, submit answers, calculate results on the backend and save an attempt.

## Work split

### Developer A — PDF and question engine
- [ ] Implement PDF validation.
- [ ] Extract page text using PyMuPDF.
- [ ] Normalize extracted text.
- [ ] Return extraction metadata and preview.
- [ ] Implement basic source-grounded rule-based MCQ generation.
- [ ] Add question structure validation.
- [ ] Handle insufficient source text gracefully.
- [ ] Share agreed function signatures with Developer B.

Files owned:
- `pdf_processor.py`
- `quiz_generator.py`

### Developer B — API and persistence
- [ ] Create FastAPI application.
- [ ] Implement health endpoint.
- [ ] Implement PDF upload endpoint and call Developer A's processor.
- [ ] Implement quiz-generation endpoint.
- [ ] Implement SQLite models and initialization.
- [ ] Implement backend submission evaluation.
- [ ] Implement history endpoint.
- [ ] Add CORS for local frontend origin.
- [ ] Share endpoint contracts with Developer A.

Files owned:
- `main.py`
- `database.py`
- `models.py`

### Shared integration
- [ ] Agree on function signatures and response schemas before coding.
- [ ] Integrate by minute 20.
- [ ] Test upload-to-quiz flow.
- [ ] Test answer submission and server-side scoring.
- [ ] Test history persistence.
- [ ] Connect frontend Fetch API calls.
- [ ] Test one known text-based PDF end-to-end.

## 50-minute timebox
| Minute | Milestone |
|---|---|
| 0–5 | Environment, folders, API contracts |
| 5–20 | Parallel module development |
| 20–30 | Integrate upload and generation |
| 30–40 | Evaluation, SQLite and tests |
| 40–50 | Frontend integration and demo rehearsal |

## Definition of done
- Backend starts.
- Valid PDF uploads and extracts text.
- Quiz generation returns valid questions.
- Correct answers are not sent to the browser before exam submission.
- Backend calculates score.
- Attempt is saved and returned by history.
- Invalid PDF and insufficient-content cases show understandable errors.

## Explicitly defer
Authentication, OCR, real LLM integration, cloud storage, multiplayer, payments and advanced analytics.

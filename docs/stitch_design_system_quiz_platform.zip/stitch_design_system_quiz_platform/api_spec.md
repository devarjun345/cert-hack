# Grimoire — API Specification

Base URL for local development: `http://127.0.0.1:8000`

## General conventions
- JSON responses use UTF-8.
- PDF upload uses `multipart/form-data`.
- IDs are opaque identifiers; clients must not construct them.
- Correct answers remain server-side until submission.
- Errors should use a consistent shape:
```json
{
  "detail": "A clear explanation of the problem"
}
```

## 1. Health check
`GET /`

Response:
```json
{
  "status": "ok",
  "app": "Grimoire"
}
```

## 2. Upload PDF
`POST /api/upload-pdf`

Content type: `multipart/form-data`  
Field: `file`

Success response:
```json
{
  "document_id": "doc_example",
  "filename": "chapter-one.pdf",
  "page_count": 12,
  "extraction_status": "success",
  "text_preview": "First extracted lines..."
}
```

Expected errors:
- `400` invalid or unreadable PDF.
- `413` file exceeds configured size limit.
- `422` no extractable text / unsupported document.

## 3. Generate quiz
`POST /api/generate-quiz`

Request:
```json
{
  "document_id": "doc_example",
  "question_count": 5,
  "difficulty": "easy",
  "mode": "exam"
}
```

Success response:
```json
{
  "quiz_id": "quiz_example",
  "document_id": "doc_example",
  "difficulty": "easy",
  "mode": "exam",
  "questions": [
    {
      "id": "q1",
      "question": "Example question based on the document?",
      "options": [
        {"id": "A", "text": "Option one"},
        {"id": "B", "text": "Option two"},
        {"id": "C", "text": "Option three"},
        {"id": "D", "text": "Option four"}
      ]
    }
  ]
}
```
Do not include `correct_option_id` or answer explanations in this response for Exam Mode.

## 4. Submit quiz
`POST /api/submit-quiz`

Request:
```json
{
  "quiz_id": "quiz_example",
  "answers": [
    {"question_id": "q1", "option_id": "B"}
  ],
  "time_taken_seconds": 95
}
```

Success response:
```json
{
  "attempt_id": 1,
  "total_questions": 5,
  "correct": 3,
  "incorrect": 1,
  "unanswered": 1,
  "score": 3,
  "accuracy": 60.0,
  "time_taken_seconds": 95,
  "review": [
    {
      "question_id": "q1",
      "selected_option_id": "B",
      "correct_option_id": "B",
      "is_correct": true,
      "explanation": "Explanation grounded in the source text."
    }
  ]
}
```

The backend must calculate all score fields. Reject unknown question or option IDs.

## 5. Quiz history
`GET /api/history`

Optional query: `?limit=20`

Response:
```json
{
  "items": [
    {
      "attempt_id": 1,
      "document_name": "chapter-one.pdf",
      "score": 3,
      "total_questions": 5,
      "accuracy": 60.0,
      "attempted_at": "2026-11-27T10:00:00"
    }
  ]
}
```

## Integration agreement
Developer A owns `pdf_processor.py` and `quiz_generator.py`. Developer B owns `main.py`, `database.py` and `models.py`. Both developers must preserve the request/response shapes above or agree on changes before integration.

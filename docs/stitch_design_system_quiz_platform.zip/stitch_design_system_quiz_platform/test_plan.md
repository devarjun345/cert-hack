# Grimoire — MVP Test Plan

## Test environment
- Local frontend served over HTTP.
- FastAPI backend at `http://127.0.0.1:8000`.
- SQLite database.
- A known text-based PDF with selectable text.

## Functional test cases

| ID | Test | Expected result |
|---|---|---|
| T01 | Open `GET /` | Health response identifies Grimoire |
| T02 | Upload valid text PDF | Document ID and extracted preview returned |
| T03 | Upload `.txt` renamed as `.pdf` | Rejected as invalid PDF |
| T04 | Upload oversized PDF | Rejected with size-limit error |
| T05 | Upload empty/scanned PDF | Clear no-text or unsupported response |
| T06 | Generate quiz from valid document | Questions and four options returned |
| T07 | Request unsupported difficulty | Validation error or documented default |
| T08 | Inspect Exam Mode response | No correct-answer key exposed |
| T09 | Submit correct and incorrect answers | Backend returns correct score |
| T10 | Submit unknown question/option ID | Request rejected |
| T11 | Retrieve history | Saved attempt appears |
| T12 | Restart backend and retrieve history | SQLite attempt remains available |

## Manual end-to-end test
1. Start backend.
2. Open frontend.
3. Upload the known PDF.
4. Confirm extracted preview.
5. Generate five questions.
6. Complete the quiz.
7. Submit answers.
8. Compare score with known answer selections.
9. Refresh history and confirm the attempt is saved.

## Demo readiness checklist
- [ ] Backend starts without errors.
- [ ] CORS allows the frontend origin.
- [ ] Sample PDF is available locally.
- [ ] Upload works.
- [ ] Generated questions are relevant to the PDF.
- [ ] Timer works.
- [ ] Backend scoring is correct.
- [ ] History persists.
- [ ] No answer keys leak before submission.
- [ ] Error states are present.

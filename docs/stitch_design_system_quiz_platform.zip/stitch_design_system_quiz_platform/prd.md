# GRIMOIRE — Product Requirements Document

**Version:** 1.0  
**Status:** MVP specification  
**Product:** Web-based PDF-to-Quiz platform

## 1. Product overview
Grimoire turns educational PDF documents into interactive quizzes. A learner uploads a text-based PDF, the backend extracts its text, a question-generation engine creates multiple-choice questions, and the learner completes a timed assessment. The backend evaluates submitted answers and stores attempt summaries.

**Product promise:** Upload a PDF. Generate a quiz. Test your knowledge.

## 2. Problem
Students often study from static PDFs and lecture notes. Creating practice questions manually takes time, and learners may lack a convenient way to test their understanding or review performance.

## 3. Goals
- Accept and validate PDF uploads.
- Extract readable text from supported PDFs.
- Generate MCQs grounded in extracted document content.
- Let learners configure question count and difficulty.
- Provide a timed quiz experience.
- Evaluate submissions on the backend.
- Save and retrieve quiz attempt summaries.

## 4. Target users
- Primary: students preparing from lecture notes, textbooks and course PDFs.
- Secondary: independent learners using digital study materials.
- Future: teachers and training providers.

## 5. MVP user journey
1. Open the Grimoire dashboard.
2. Upload a text-based PDF.
3. Backend validates the file and extracts text.
4. Learner selects question count, difficulty and mode.
5. Backend generates quiz questions from the extracted text.
6. Learner answers questions in the quiz interface.
7. Learner submits, or the timer expires.
8. Backend evaluates answers and returns results.
9. Attempt summary is saved and can be viewed in history.

## 6. Functional requirements

### FR-01 Dashboard
- Show Grimoire branding.
- Provide a clear PDF upload action.
- Show recent attempts and summary statistics when available.

### FR-02 PDF ingestion
- Accept PDF files only.
- Enforce a configurable file-size limit.
- Reject empty, corrupt, encrypted or unsupported documents with a clear message.
- Extract text from pages using PyMuPDF.
- Return a document ID, filename, page count and a short text preview.
- Do not assume scanned PDFs are readable; OCR is out of MVP scope.

### FR-03 Quiz configuration
- Support question counts such as 5, 10, 15 and 20, subject to available content.
- Support Easy, Medium and Hard labels.
- Support Study Mode and Exam Mode.
- Allow a quiz duration to be selected or use a sensible default.

### FR-04 Question generation
- Generate MCQs using only extracted document content.
- Return four options and one correct answer per question.
- Keep answer keys and evaluation metadata on the server.
- Avoid duplicate questions where possible.
- Validate each generated question before returning it.
- If there is insufficient source content, return fewer questions or a clear error rather than inventing facts.

**MVP truth-in-labeling:** The initial generator is rule-based. Do not describe it as LLM/AI-generated unless a real model is integrated.

### FR-05 Quiz experience
- Show one question at a time or a clear question list.
- Allow answer selection and question navigation.
- Show answered/unanswered status.
- Display a countdown timer.
- Submit manually or automatically on timeout.
- In Exam Mode, do not reveal correct answers before submission.
- In Study Mode, feedback may be shown after each answer if implemented.

### FR-06 Evaluation and results
- Evaluate responses on the backend.
- Return total, correct, incorrect, unanswered, score and accuracy.
- Return explanations only after submission in Exam Mode.
- Validate quiz ID and submitted answer identifiers.
- Prevent repeated submissions from changing a completed attempt.

### FR-07 History
- Save quiz attempt metadata and result summary in SQLite.
- Retrieve recent attempts.
- Store only what is required for the demo; avoid retaining full PDF text unnecessarily.

## 7. Non-functional requirements
- Responsive layout for desktop and mobile.
- Clear loading, success and error states.
- Validate uploaded file type, size and content.
- Never execute uploaded files.
- Do not expose answer keys in quiz-generation responses.
- Keep API keys out of browser code.
- Use predictable API response structures.
- Handle malformed requests and processing failures gracefully.

## 8. MVP scope
**Included:** PDF upload, text extraction, basic rule-based MCQ generation, quiz setup, timer, answer submission, backend evaluation, results and basic SQLite history.

**Excluded:** account registration, authentication, OCR, multiplayer, leaderboards, cloud storage, payments, adaptive learning and real LLM integration.

## 9. Success criteria / acceptance tests
- A valid text-based PDF can be uploaded.
- Extracted text preview is non-empty for a supported document.
- Invalid files are rejected safely.
- Generated questions are traceable to extracted content.
- Each question has four distinct options and one server-side correct answer.
- Exam Mode does not expose answer keys before submission.
- Backend evaluation returns correct totals and accuracy.
- Attempt summaries persist in SQLite and appear in history.
- Full upload-to-results workflow completes without manual database edits.

## 10. Future roadmap
- LLM-based question generation with source-grounded prompts.
- OCR for scanned documents.
- Topic/chapter selection.
- PDF summaries and flashcards.
- User accounts and cloud synchronization.
- Adaptive difficulty and personalized revision.
- Exportable quiz reports.

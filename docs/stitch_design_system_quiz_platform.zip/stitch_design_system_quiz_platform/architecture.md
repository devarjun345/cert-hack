# Grimoire — System Architecture

## 1. Architecture summary
Grimoire uses a browser frontend, a FastAPI backend, a document/question processing layer and SQLite persistence.

```text
Browser UI
  |  HTTP / JSON / multipart upload
  v
FastAPI application
  |-- PDF validation and extraction (PyMuPDF)
  |-- Quiz generation module (rule-based MVP)
  |-- Submission evaluation service
  |-- History service
  v
SQLite database
```

## 2. Component responsibilities

### Frontend
- Upload PDF and display upload progress.
- Show extracted document metadata/preview.
- Submit quiz configuration.
- Render questions and maintain temporary selected answers.
- Manage visible countdown timer.
- Submit answers and render server-calculated results.
- Request and display history.

### FastAPI application
- Validate request payloads and uploaded files.
- Orchestrate processing modules.
- Keep answer keys server-side.
- Return consistent HTTP status codes and JSON responses.
- Enforce file-size and question-count limits.

### PDF processor
- Read PDF bytes safely.
- Extract text page by page using PyMuPDF.
- Normalize whitespace.
- Report page count and extraction status.
- Reject documents with no extractable text.

### Quiz generator
- Accept extracted text and requested configuration.
- Create candidate questions from supported text patterns.
- Generate plausible but clearly distinguishable options only when defensible.
- Attach source snippets and answer keys internally.
- Return a controlled error if sufficient questions cannot be generated.

### Database
- Store document metadata, quiz metadata and attempt summaries.
- Avoid storing full extracted text unless necessary for the demo.

## 3. Data flow
1. Browser sends multipart PDF upload.
2. API validates extension, MIME type, size and PDF readability.
3. Processor extracts text.
4. API assigns a document ID and retains required content for quiz creation.
5. Browser sends document ID and quiz settings.
6. Generator creates quiz and API returns question text/options without correct answers.
7. Browser submits selected option IDs.
8. Evaluator compares submitted IDs with server-side answer keys.
9. Database stores attempt summary.
10. API returns results and history becomes available.

## 4. Trust boundaries
- Treat all uploaded documents as untrusted input.
- Never trust a score calculated by the browser.
- Never expose correct answer keys before submission.
- Validate document IDs, quiz IDs and answer IDs.
- Do not accept arbitrary filesystem paths from clients.
- Keep uploads in a controlled directory and use generated filenames.

## 5. MVP design choices
- One local backend process.
- SQLite database.
- Local temporary upload storage.
- No authentication for the demo.
- Text-based PDF support only.
- Rule-based question generation.

## 6. Future extension points
The `quiz_generator` module should expose a stable interface so a real LLM provider can replace the rule-based implementation without changing the frontend contract. OCR can later be added behind the PDF-processing interface.
